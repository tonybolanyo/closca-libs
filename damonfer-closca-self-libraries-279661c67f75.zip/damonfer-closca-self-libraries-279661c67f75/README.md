# CLOSCA SELF LIBRARIES
## node_modules 
Contains a dependency of the library used in:
- closca-admin-panel 
- closca-web-manage-accounts.
